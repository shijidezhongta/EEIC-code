# -*- coding: utf-8 -*-
"""win and widgets for app

Copyright (c) 2019 lileilei <hustlei@sina.cn>
"""

from .mainwinbase import MainWinBase
